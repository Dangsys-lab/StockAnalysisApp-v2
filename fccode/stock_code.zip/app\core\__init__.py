# -*- coding: utf-8 -*-
"""
Core层 - 核心业务逻辑
"""
